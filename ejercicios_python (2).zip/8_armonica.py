# Programa: Sumar serie armónica

n = int(input("Ingrese un valor para n: "))

suma = 0

for i in range(1, n + 1):
    suma += 1 / i

print("La suma armónica es:", suma)
