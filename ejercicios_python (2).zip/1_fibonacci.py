# Programa: Serie Fibonacci hasta N

N = int(input("Ingrese un número límite: "))

# Valores iniciales de la serie
a = 0
b = 1

# Mientras el valor no supere N, lo mostramos
while a <= N:
    print(a)
    nuevo = a + b
    a = b
    b = nuevo
