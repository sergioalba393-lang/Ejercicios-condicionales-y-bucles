# Programa: Menú repetitivo

opcion = ""

while opcion != "3":
    print("----- MENÚ -----")
    print("1. Sumar")
    print("2. Restar")
    print("3. Salir")

    opcion = input("Elija una opción: ")

    if opcion == "1":
        a = float(input("Ingrese el primer número: "))
        b = float(input("Ingrese el segundo número: "))
        print("Resultado:", a + b)

    elif opcion == "2":
        a = float(input("Ingrese el primer número: "))
        b = float(input("Ingrese el segundo número: "))
        print("Resultado:", a - b)

    elif opcion == "3":
        print("Saliendo del programa...")

    else:
        print("Opción no válida")
