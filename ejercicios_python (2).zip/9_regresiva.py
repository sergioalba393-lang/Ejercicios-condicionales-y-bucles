# Programa: Cuenta regresiva con alerta

num = int(input("Ingrese un número para iniciar la cuenta regresiva: "))

for i in range(num, 0, -1):
    print(i)
    if i % 7 == 0:
        print(" --> ALERTA: múltiplo de 7")

print(0)
