# Programa: Suma continua hasta ingresar 0

suma = 0

while True:
    numero = int(input("Ingrese un número (0 para terminar): "))

    if numero == 0:
        break

    if numero < 0:
        # Ignoro negativos
        continue

    suma += numero

print("La suma total es:", suma)
