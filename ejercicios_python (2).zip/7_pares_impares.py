# Programa: Contar pares e impares

pares = 0
impares = 0

while True:
    numero = int(input("Número (0 para terminar): "))

    if numero == 0:
        break

    if numero % 2 == 0:
        pares += 1
    else:
        impares += 1

print("Cantidad de pares:", pares)
print("Cantidad de impares:", impares)
