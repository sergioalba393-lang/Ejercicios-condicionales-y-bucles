# Programa: Determinar si un número es primo

num = int(input("Ingrese un número: "))

es_primo = True

# Un número menor o igual a 1 no es primo
if num <= 1:
    es_primo = False
else:
    # Reviso divisores desde 2 hasta la raíz cuadrada
    for i in range(2, int(num ** 0.5) + 1):
        if num % i == 0:
            es_primo = False
            break

if es_primo:
    print("El número es primo")
else:
    print("El número NO es primo")
